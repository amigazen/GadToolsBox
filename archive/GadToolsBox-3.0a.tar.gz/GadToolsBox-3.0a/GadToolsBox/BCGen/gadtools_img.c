/*
** gadtools_img.c Images File
*/

#include<proto/exec.h>
#include<proto/graphics.h>
#include"gadtools.h"


