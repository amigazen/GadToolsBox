#define	VERSION		39
#define	REVISION	1
#define	DATE	"10.1.98"
#define	VERS	"smartbitmap.image 39.1"
#define	VSTRING	"smartbitmap.image 39.1 (10.1.98)\r\n"
#define	VERSTAG	"\0$VER: smartbitmap.image 39.1 (10.1.98)"
