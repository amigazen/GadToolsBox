#define	VERSION		37
#define	REVISION	2
#define	DATE	"18.4.98"
#define	VERS	"listview.gadget 37.2"
#define	VSTRING	"listview.gadget 37.2 (18.4.98)\r\n"
#define	VERSTAG	"\0$VER: listview.gadget 37.2 (18.4.98)"
