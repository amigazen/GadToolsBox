#include<exec/memory.h>

void *AllocVecPooled(void *,ULONG);
void FreeVecPooled(void *,void *);
