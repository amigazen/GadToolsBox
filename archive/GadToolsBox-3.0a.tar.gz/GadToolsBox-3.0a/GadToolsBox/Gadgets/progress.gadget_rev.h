#define	VERSION		37
#define	REVISION	1
#define	DATE	"15.1.98"
#define	VERS	"progress.gadget 37.1"
#define	VSTRING	"progress.gadget 37.1 (15.1.98)\r\n"
#define	VERSTAG	"\0$VER: progress.gadget 37.1 (15.1.98)"
