#define	VERSION		37
#define	REVISION	1
#define	DATE	"27.6.98"
#define	VERS	"page.gadget 37.1"
#define	VSTRING	"page.gadget 37.1 (27.6.98)\r\n"
#define	VERSTAG	"\0$VER: page.gadget 37.1 (27.6.98)"
