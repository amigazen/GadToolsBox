#include<proto/utility.h>
#include<exec/types.h>
#include"gadtoolsbox.h"

#define GADG_Dummy (TAG_USER)
#define GADG_Kind (GADG_Dummy+0)
#define GADG_Screen (GADG_Dummy+1)
#define GADG_Handler (MESG_Dummy+31)
