/*
** gadtools_cat.c Catalog File
*/

#include<proto/locale.h>
#include"gadtools_cat.h"

const struct FC_Type _MSG_SCREENTITLE_SCR = { 0, "" };
const struct FC_Type _MSG_Prefs_WND = { 1, "Prefs: c.generator" };
const struct FC_Type _MSG_TEMPLATE_GAD = { 2, "_Template:" };
const struct FC_Type _MSG_GUIFUNCS_GAD = { 3, "_GUI functions:" };
const struct FC_Type _MSG_LOCALIZE_GAD = { 4, "_Localize:" };
const struct FC_Type _MSG_SAVE_GAD = { 5, "_Save" };
const struct FC_Type _MSG_CANCEL_GAD = { 6, "_Cancel" };
const struct FC_Type _MSG_USE_GAD = { 7, "_Use" };
const struct FC_Type _MSG_SCREEN_GAD = { 8, "_Screen:" };


